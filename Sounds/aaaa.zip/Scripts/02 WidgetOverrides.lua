Widg.defaults.button.highlight.color = color("#4444ccff")
Widg.defaults.button.bgColor = color("#3333aaff")
Widg.defaults.button.texture = "medium-robot-square"
